class Image():
    def __init__(self, width, height, color):
        self.width=width
        self.height=height
        self.color=color