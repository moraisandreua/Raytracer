class Light():
    def __init__(self, transformation, color):
        self.transformation=transformation
        self.color=color