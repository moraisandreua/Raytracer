class Triangles():
    def __init__(self, transformation, triangles):
        self.transformation=transformation
        self.triangles=triangles
